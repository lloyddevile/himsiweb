const crypto = require("node:crypto");

const MAX_BODY_BYTES = 8192;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function respond(res, status, payload) {
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    return res.status(status).json(payload);
}

function getRequestBody(req) {
    if (typeof req.body === "string") {
        try {
            return JSON.parse(req.body);
        } catch {
            return null;
        }
    }

    return req.body;
}

function validateRegistration(body) {
    if (!body || typeof body !== "object" || Array.isArray(body) || body.consent !== true) {
        return null;
    }

    const fields = ["name", "program", "semester", "whatsapp"];
    const limits = { name: 120, program: 120, semester: 2, whatsapp: 24 };
    const values = {};
    for (const field of fields) {
        if (typeof body[field] !== "string") {
            return null;
        }
        values[field] = body[field].trim();
        if (!values[field] || values[field].length > limits[field]) {
            return null;
        }
    }

    if (!UUID_PATTERN.test(body.activity_id)
        || !/^(?:[1-9]|1[0-4])$/.test(values.semester)
        || !/^\+62[0-9 -]{8,16}$/.test(values.whatsapp)) {
        return null;
    }

    const whatsappDigits = values.whatsapp.replace(/\D/g, "");
    if (whatsappDigits.length < 10 || whatsappDigits.length > 15) {
        return null;
    }

    values.activity_id = body.activity_id;
    values.semester = Number(values.semester);
    values.whatsapp = `+${whatsappDigits}`;
    return values;
}

async function callSupabaseRpc(projectUrl, serviceKey, name, body) {
    const upstream = await fetch(`${projectUrl.origin}/rest/v1/rpc/${name}`, {
        method: "POST",
        headers: {
            apikey: serviceKey,
            Authorization: `Bearer ${serviceKey}`,
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    });

    let payload;
    try {
        payload = await upstream.json();
    } catch {
        payload = null;
    }

    if (!upstream.ok || !payload || typeof payload !== "object") {
        const error = new Error("Supabase rejected an activity registration request.");
        error.status = upstream.status;
        error.code = payload?.code;
        throw error;
    }
    return payload;
}

function getPublicError(error) {
    if (error === "invalid_registration") {
        return { status: 400, payload: { error } };
    }
    if (error === "rate_limited") {
        return { status: 429, payload: { error } };
    }
    if (error === "activity_full"
        || error === "already_registered"
        || error === "registration_closed"
        || error === "payment_in_progress") {
        return { status: 409, payload: { error } };
    }
    return null;
}

module.exports = async function handleActivityRegistration(req, res) {
    if (req.method !== "POST") {
        res.setHeader("Allow", "POST");
        return respond(res, 405, { error: "method_not_allowed" });
    }

    const contentType = req.headers["content-type"] || "";
    if (!contentType.toLowerCase().startsWith("application/json")) {
        return respond(res, 415, { error: "unsupported_media_type" });
    }

    const contentLength = Number(req.headers["content-length"] || 0);
    if (contentLength > MAX_BODY_BYTES) {
        return respond(res, 413, { error: "request_too_large" });
    }

    const origin = req.headers.origin;
    const host = req.headers.host;
    if (!origin || !host) {
        return respond(res, 403, { error: "origin_not_allowed" });
    }
    try {
        if (new URL(origin).host !== host) {
            return respond(res, 403, { error: "origin_not_allowed" });
        }
    } catch {
        return respond(res, 403, { error: "origin_not_allowed" });
    }

    const registration = validateRegistration(getRequestBody(req));
    if (!registration) {
        return respond(res, 400, { error: "invalid_registration" });
    }

    const supabaseUrl = process.env.SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !serviceKey) {
        console.error("Activity registration API is missing its Supabase environment configuration.");
        return respond(res, 503, { error: "registration_unavailable" });
    }

    let projectUrl;
    try {
        projectUrl = new URL(supabaseUrl);
        if (projectUrl.protocol !== "https:" && projectUrl.hostname !== "localhost" && projectUrl.hostname !== "127.0.0.1") {
            throw new Error("Supabase URL must use HTTPS.");
        }
    } catch {
        console.error("Activity registration API has an invalid Supabase URL.");
        return respond(res, 503, { error: "registration_unavailable" });
    }

    const forwardedFor = req.headers["x-forwarded-for"];
    const requesterAddress = typeof forwardedFor === "string"
        ? forwardedFor.split(",")[0].trim()
        : req.socket?.remoteAddress || "unknown";
    const requesterHash = crypto
        .createHmac("sha256", serviceKey)
        .update(requesterAddress)
        .digest("hex");

    try {
        const orderId = `HMPS-${crypto.randomUUID()}`;
        const payload = await callSupabaseRpc(
            projectUrl,
            serviceKey,
            "submit_activity_registration",
            {
                p_activity_id: registration.activity_id,
                p_name: registration.name,
                p_program: registration.program,
                p_semester: String(registration.semester),
                p_whatsapp: registration.whatsapp,
                p_requester_hash: requesterHash,
                p_order_id: orderId,
            }
        );

        if (!payload.ok) {
            const publicError = getPublicError(payload.error);
            if (!publicError) {
                console.error("Supabase returned an unknown activity registration result.");
                return respond(res, 502, { error: "registration_not_saved" });
            }
            return respond(res, publicError.status, publicError.payload);
        }

        if (!payload.requires_payment) {
            return respond(res, 201, { ok: true, registered: true });
        }

        if (payload.reused !== true && typeof payload.checkout_url !== "string") {
            const failedPayment = await callSupabaseRpc(
                projectUrl,
                serviceKey,
                "apply_activity_registration_payment",
                {
                    p_order_id: payload.order_id,
                    p_transaction_status: "failed",
                    p_gross_amount: null,
                    p_payment_type: null,
                    p_transaction_id: null,
                }
            );
            if (!failedPayment.ok) {
                console.error("Supabase could not close a paid registration while payments are disabled.", {
                    error: failedPayment.error,
                });
                return respond(res, 502, { error: "registration_not_saved" });
            }
        }

        return respond(res, 503, { error: "payment_unavailable" });
    } catch (error) {
        const migrationMissing = error.code === "PGRST202" || error.code === "PGRST203";
        console.error("Activity registration API could not complete its server request.", {
            status: error.status,
            code: error.code,
        });
        return respond(res, migrationMissing ? 503 : 502, {
            error: migrationMissing ? "registration_unavailable" : "registration_not_saved",
        });
    }
};
