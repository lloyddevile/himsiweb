function respond(res, status, payload) {
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    return res.status(status).json(payload);
}

function isValidActivityGroupInviteUrl(value) {
    if (typeof value !== "string" || value !== value.trim()) {
        return false;
    }

    let url;
    try {
        url = new URL(value);
    } catch {
        return false;
    }
    if (url.protocol !== "https:" || url.username || url.password) {
        return false;
    }

    const segments = url.pathname.split("/").filter(Boolean);
    const isInviteCode = (code) => /^[A-Za-z0-9_-]+$/.test(code);
    if (url.hostname === "chat.whatsapp.com" || url.hostname === "discord.gg") {
        return segments.length === 1 && isInviteCode(segments[0]);
    }
    if (url.hostname === "discord.com") {
        return segments.length === 2 && segments[0] === "invite" && isInviteCode(segments[1]);
    }
    if (url.hostname === "t.me" || url.hostname === "telegram.me") {
        if (segments.length === 1) {
            return /^\+[A-Za-z0-9_-]+$/.test(segments[0])
                || /^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(segments[0]);
        }
        return segments.length === 2
            && segments[0] === "joinchat"
            && isInviteCode(segments[1]);
    }
    return false;
}

module.exports = async function handleActivityRegistrationConfirmation(req, res) {
    if (req.method !== "GET") {
        res.setHeader("Allow", "GET");
        return respond(res, 405, { error: "method_not_allowed" });
    }

    const origin = req.headers.origin;
    const host = req.headers.host;
    if (!host) {
        return respond(res, 403, { error: "origin_not_allowed" });
    }
    if (origin) {
        try {
            if (new URL(origin).host !== host) {
                return respond(res, 403, { error: "origin_not_allowed" });
            }
        } catch {
            return respond(res, 403, { error: "origin_not_allowed" });
        }
    }

    const orderId = req.query?.order_id
        || new URL(req.url, `https://${host}`).searchParams.get("order_id");
    if (typeof orderId !== "string" || !/^HMPS-[0-9a-f-]{36}$/.test(orderId)) {
        return respond(res, 400, { error: "invalid_order" });
    }

    const supabaseUrl = process.env.SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !serviceKey) {
        console.error("Registration confirmation API is missing its Supabase environment configuration.");
        return respond(res, 503, { error: "confirmation_unavailable" });
    }

    let projectUrl;
    try {
        projectUrl = new URL(supabaseUrl);
        if (projectUrl.protocol !== "https:"
            && projectUrl.hostname !== "localhost"
            && projectUrl.hostname !== "127.0.0.1") {
            throw new Error("Supabase URL must use HTTPS.");
        }
    } catch {
        console.error("Registration confirmation API has an invalid Supabase URL.");
        return respond(res, 503, { error: "confirmation_unavailable" });
    }

    try {
        const upstream = await fetch(
            `${projectUrl.origin}/rest/v1/rpc/get_activity_registration_confirmation`,
            {
                method: "POST",
                headers: {
                    apikey: serviceKey,
                    Authorization: `Bearer ${serviceKey}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ p_order_id: orderId }),
            }
        );

        let payload;
        try {
            payload = await upstream.json();
        } catch {
            payload = null;
        }
        if (!upstream.ok || !payload || typeof payload !== "object") {
            console.error("Supabase could not retrieve an activity registration confirmation.", {
                status: upstream.status,
                code: payload?.code,
            });
            return respond(res, 503, { error: "confirmation_unavailable" });
        }
        if (!payload.ok) {
            return respond(res, 404, { error: "unknown_order" });
        }

        const groupLink = payload.status === "registered"
            && isValidActivityGroupInviteUrl(payload.whatsapp_group_link)
            ? payload.whatsapp_group_link
            : null;
        return respond(res, 200, {
            ok: true,
            status: payload.status,
            whatsapp_group_link: groupLink,
        });
    } catch (error) {
        console.error("Activity registration confirmation API could not reach Supabase.", error);
        return respond(res, 502, { error: "confirmation_unavailable" });
    }
};
