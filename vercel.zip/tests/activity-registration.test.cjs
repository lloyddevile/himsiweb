const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const { afterEach, test } = require("node:test");
const crypto = require("node:crypto");
const registrationHandler = require("../api/activity-registrations");
const confirmationHandler = require("../api/activity-registration-confirmation");

const root = path.join(__dirname, "..");
const originalFetch = global.fetch;
const environmentKeys = [
    "SUPABASE_URL",
    "SUPABASE_SERVICE_ROLE_KEY",
];
const originalEnvironment = Object.fromEntries(
    environmentKeys.map((key) => [key, process.env[key]])
);

afterEach(() => {
    global.fetch = originalFetch;
    environmentKeys.forEach((key) => {
        if (originalEnvironment[key] === undefined) {
            delete process.env[key];
        } else {
            process.env[key] = originalEnvironment[key];
        }
    });
});

function makeResponse() {
    return {
        headers: {},
        statusCode: null,
        body: null,
        setHeader(name, value) {
            this.headers[name] = value;
        },
        status(code) {
            this.statusCode = code;
            return this;
        },
        json(body) {
            this.body = body;
            return this;
        },
    };
}

function registrationRequest(overrides = {}) {
    return {
        method: "POST",
        headers: {
            "content-type": "application/json",
            "content-length": "220",
            "x-forwarded-for": "203.0.113.8",
            host: "hmpssi.vercel.app",
            origin: "https://hmpssi.vercel.app",
        },
        body: {
            activity_id: "9b2f3b2a-ff51-4e31-b22f-9f18fdb68a11",
            name: "  Dewi  ",
            program: " Sistem Informasi ",
            semester: "3",
            whatsapp: "+62 812-3456-7890",
            consent: true,
        },
        ...overrides,
    };
}

test("activity registration validates consent and same-origin requests before calling Supabase", async () => {
    global.fetch = async () => {
        throw new Error("Supabase must not be called for invalid requests");
    };
    const invalid = makeResponse();
    await registrationHandler(registrationRequest({
        body: { ...registrationRequest().body, consent: false },
    }), invalid);
    assert.equal(invalid.statusCode, 400);
    assert.equal(invalid.body.error, "invalid_registration");

    const invalidPhone = makeResponse();
    await registrationHandler(registrationRequest({
        body: { ...registrationRequest().body, whatsapp: "0812-3456-7890" },
    }), invalidPhone);
    assert.equal(invalidPhone.statusCode, 400);

    const crossOrigin = makeResponse();
    await registrationHandler(registrationRequest({
        headers: {
            "content-type": "application/json",
            host: "hmpssi.vercel.app",
            origin: "https://attacker.example",
        },
    }), crossOrigin);
    assert.equal(crossOrigin.statusCode, 403);
    assert.equal(crossOrigin.body.error, "origin_not_allowed");
});

test("free activity registration calls the server-only RPC with the configured participant fields", async () => {
    process.env.SUPABASE_URL = "https://project.supabase.co";
    process.env.SUPABASE_SERVICE_ROLE_KEY = "server-secret";
    let requestOptions;
    global.fetch = async (url, options) => {
        requestOptions = { url, options };
        return new Response(JSON.stringify({
            ok: true,
            registration_id: "a1af3bf5-6d3c-4826-9d8c-d74ff79df119",
        }), { status: 200 });
    };
    const response = makeResponse();

    await registrationHandler(registrationRequest(), response);

    assert.equal(response.statusCode, 201);
    assert.deepEqual(response.body, { ok: true, registered: true });
    assert.equal(response.headers["Cache-Control"], "no-store");
    assert.equal(requestOptions.url, "https://project.supabase.co/rest/v1/rpc/submit_activity_registration");
    assert.equal(requestOptions.options.headers.apikey, "server-secret");
    const payload = JSON.parse(requestOptions.options.body);
    assert.equal(payload.p_name, "Dewi");
    assert.equal(payload.p_program, "Sistem Informasi");
    assert.equal(payload.p_semester, "3");
    assert.equal(payload.p_whatsapp, "+6281234567890");
    assert.match(payload.p_order_id, /^HMPS-[0-9a-f-]{36}$/);
    assert.equal(
        payload.p_requester_hash,
        crypto.createHmac("sha256", "server-secret").update("203.0.113.8").digest("hex")
    );
});

test("activity registration maps full, duplicate, closed, and rate-limited results", async () => {
    process.env.SUPABASE_URL = "https://project.supabase.co";
    process.env.SUPABASE_SERVICE_ROLE_KEY = "server-secret";
    for (const [error, status] of [
        ["activity_full", 409],
        ["already_registered", 409],
        ["registration_closed", 409],
        ["rate_limited", 429],
    ]) {
        global.fetch = async () => new Response(JSON.stringify({ ok: false, error }), { status: 200 });
        const response = makeResponse();
        await registrationHandler(registrationRequest(), response);
        assert.equal(response.statusCode, status);
        assert.equal(response.body.error, error);
    }
});

test("paid activity registration is disabled without calling a payment provider", async () => {
    process.env.SUPABASE_URL = "https://project.supabase.co";
    process.env.SUPABASE_SERVICE_ROLE_KEY = "server-secret";
    const calls = [];
    global.fetch = async (url, options) => {
        calls.push({ url, options });
        if (url.endsWith("/rpc/submit_activity_registration")) {
            return new Response(JSON.stringify({
                ok: true,
                requires_payment: true,
                reused: false,
                order_id: "HMPS-9b2f3b2a-ff51-4e31-b22f-9f18fdb68a11",
            }), { status: 200 });
        }
        if (url.endsWith("/rpc/apply_activity_registration_payment")) {
            return new Response(JSON.stringify({ ok: true }), { status: 200 });
        }
        throw new Error(`Unexpected request: ${url}`);
    };

    const response = makeResponse();
    await registrationHandler(registrationRequest(), response);

    assert.equal(response.statusCode, 503);
    assert.deepEqual(response.body, { error: "payment_unavailable" });
    assert.deepEqual(calls.map(({ url }) => url), [
        "https://project.supabase.co/rest/v1/rpc/submit_activity_registration",
        "https://project.supabase.co/rest/v1/rpc/apply_activity_registration_payment",
    ]);
    assert.deepEqual(JSON.parse(calls[1].options.body), {
        p_order_id: "HMPS-9b2f3b2a-ff51-4e31-b22f-9f18fdb68a11",
        p_transaction_status: "failed",
        p_gross_amount: null,
        p_payment_type: null,
        p_transaction_id: null,
    });
});

test("disabled paid registration never returns an existing checkout URL", async () => {
    process.env.SUPABASE_URL = "https://project.supabase.co";
    process.env.SUPABASE_SERVICE_ROLE_KEY = "server-secret";
    const calls = [];
    global.fetch = async (url, options) => {
        calls.push({ url, options });
        return new Response(JSON.stringify({
            ok: true,
            requires_payment: true,
            reused: true,
            checkout_url: "https://payments.example/checkout/123",
            order_id: "HMPS-9b2f3b2a-ff51-4e31-b22f-9f18fdb68a11",
        }), { status: 200 });
    };

    const response = makeResponse();
    await registrationHandler(registrationRequest(), response);

    assert.equal(response.statusCode, 503);
    assert.deepEqual(response.body, { error: "payment_unavailable" });
    assert.equal(calls.length, 1);
    assert.equal(calls[0].url, "https://project.supabase.co/rest/v1/rpc/submit_activity_registration");
});

test("activity registration reports a missing database migration without exposing upstream details", async () => {
    process.env.SUPABASE_URL = "https://project.supabase.co";
    process.env.SUPABASE_SERVICE_ROLE_KEY = "server-secret";
    global.fetch = async () => new Response(JSON.stringify({
        code: "PGRST202",
        message: "private upstream detail",
    }), { status: 404 });
    const response = makeResponse();

    await registrationHandler(registrationRequest(), response);

    assert.equal(response.statusCode, 503);
    assert.deepEqual(response.body, { error: "registration_unavailable" });
    assert.equal(JSON.stringify(response.body).includes("private upstream detail"), false);
});

test("registration is only offered for enabled, dated activities that have not passed", () => {
    const publicScript = fs.readFileSync(path.join(root, "js", "all-komponen.js"), "utf8");
    const declaration = publicScript.match(/function getOpenRegistrationActivities\(activities, today\) \{[\s\S]*?\n\}/);
    assert.ok(declaration);
    const getOpenRegistrationActivities = vm.runInNewContext(`(${declaration[0]})`);
    const activities = [
        { id: "later", title: "Lokakarya", event_date: "2026-12-10", registration_enabled: true },
        { id: "past", title: "Seminar", event_date: "2026-11-14", registration_enabled: true },
        { id: "closed", title: "Rapat", event_date: "2026-11-20", registration_enabled: false },
        { id: "undated", title: "Kegiatan", event_date: null, registration_enabled: true },
        { id: "soon", title: "Pelatihan", event_date: "2026-11-20", registration_enabled: true },
    ];

    assert.deepEqual(
        Array.from(getOpenRegistrationActivities(activities, "2026-11-15"), (activity) => activity.id),
        ["soon", "later"]
    );
});

test("the participant WhatsApp pattern is valid in Unicode sets mode", () => {
    const publicScript = fs.readFileSync(path.join(root, "js", "all-komponen.js"), "utf8");
    const declaration = publicScript.match(/phone\.pattern = "([^"]+)";/);
    assert.ok(declaration);
    const pattern = JSON.parse(`"${declaration[1]}"`);
    const regex = new RegExp(pattern, "v");

    assert.equal(regex.test("+62 812-3456 7890"), true);
    assert.equal(regex.test("0812-3456-7890"), true);
    assert.equal(regex.test("6281234567890"), true);
    assert.equal(regex.test("812-3456-7890"), false);
});

test("admin and public pages accept only secure group invite links from supported platforms", () => {
    const sources = [
        fs.readFileSync(path.join(root, "js", "admin.js"), "utf8"),
        fs.readFileSync(path.join(root, "js", "all-komponen.js"), "utf8"),
    ];
    const validLinks = [
        "https://chat.whatsapp.com/InviteCode123",
        "https://t.me/HimsiGroup",
        "https://t.me/+InviteCode123",
        "https://telegram.me/joinchat/Invite-Code",
        "https://discord.gg/Invite-Code",
        "https://discord.com/invite/Invite-Code?event=123",
    ];
    const invalidLinks = [
        "http://discord.gg/Invite-Code",
        "https://discord.com.evil.example/invite/Invite-Code",
        "https://discord.com/channels/123/456",
        "https://user:pass@t.me/HimsiGroup",
        "https://example.com/invite/InviteCode123",
    ];

    for (const source of sources) {
        const declaration = source.match(/function isValidActivityGroupInviteUrl\(value\) \{[\s\S]*?\n\}/);
        assert.ok(declaration);
        const isValid = vm.runInNewContext(`(${declaration[0]})`, { URL });
        validLinks.forEach((link) => assert.equal(isValid(link), true, link));
        invalidLinks.forEach((link) => assert.equal(isValid(link), false, link));
    }
});

test("admin configures terms, payment, group invite link, and views private participant details", () => {
    const dashboard = fs.readFileSync(path.join(root, "page", "admin.html"), "utf8");
    const adminScript = fs.readFileSync(path.join(root, "js", "admin.js"), "utf8");
    const publicScript = fs.readFileSync(path.join(root, "js", "all-komponen.js"), "utf8");
    const migration = fs.readFileSync(
        path.join(root, "supabase", "migrations", "20261116000000_activity_registrations.sql"),
        "utf8"
    );
    const paymentMigration = fs.readFileSync(
        path.join(root, "supabase", "migrations", "20261116010000_activity_registration_payments.sql"),
        "utf8"
    );
    const mustikaMigration = fs.readFileSync(
        path.join(root, "supabase", "migrations", "20261116020000_activity_registration_mustikapay.sql"),
        "utf8"
    );
    const groupInviteMigration = fs.readFileSync(
        path.join(root, "supabase", "migrations", "20261116030000_activity_registration_group_invites.sql"),
        "utf8"
    );
    const groupInviteConstraintMigration = fs.readFileSync(
        path.join(root, "supabase", "migrations", "20261116040000_activity_registration_group_invite_constraint.sql"),
        "utf8"
    );
    const homepage = fs.readFileSync(path.join(root, "page", "beranda.html"), "utf8");

    assert.match(dashboard, /name="registration_enabled" type="checkbox"/);
    assert.match(dashboard, /name="registration_capacity" type="number" min="1"/);
    assert.match(dashboard, /name="registration_terms"/);
    assert.match(dashboard, /name="registration_is_free" type="checkbox" checked/);
    assert.match(dashboard, /name="registration_fee" type="number" min="1000"/);
    assert.match(dashboard, /name="registration_payment_deadline" type="datetime-local"/);
    assert.match(dashboard, /name="registration_whatsapp_group_link"/);
    assert.match(dashboard, /Link grup peserta \(diberikan setelah pembayaran sukses\)/);
    assert.match(dashboard, /id="activityRegistrationsList"/);
    assert.match(publicScript, /Jurusan \/ Program Studi/);
    assert.match(publicScript, /Nomor WhatsApp aktif/);
    assert.match(homepage, /href="#activityRegistrations">Pendaftaran Kegiatan<\/a>/);
    assert.match(homepage, /id="activityRegistrations"/);
    assert.match(homepage, /h3>Pendaftaran Kegiatan<\/h3>/);
    assert.match(adminScript, /activity\.registration_enabled/);
    assert.match(adminScript, /activity\.registration_capacity \?\? ""/);
    assert.match(adminScript, /field === "registration_capacity" && !input\.value\s+\? null/);
    assert.match(adminScript, /form\.elements\.namedItem\("event_date"\)\.required = enabled/);
    assert.match(adminScript, /client\.from\("activity_registrations"\)/);
    assert.match(publicScript, /consent\.required = true/);
    assert.match(publicScript, /fields\.namedItem\("program"\)\.value/);
    assert.match(publicScript, /fields\.namedItem\("semester"\)\.value/);
    assert.match(publicScript, /fields\.namedItem\("whatsapp"\)\.value/);
    assert.match(publicScript, /activity\.registration_is_free === true/);
    assert.match(publicScript, /Pendaftaran berbayar sementara dinonaktifkan/);
    assert.match(publicScript, /if \(!registrationSchemaAvailable\)/);
    assert.match(migration, /for select to authenticated\s+using \(public\.is_admin\(\)\)/i);
    assert.match(migration, /for delete to authenticated\s+using \(public\.is_admin\(\)\)/i);
    assert.match(migration, /revoke all on table public\.activity_registrations from public, anon, authenticated/i);
    assert.match(migration, /for update/i);
    assert.match(migration, /v_registration_count >= v_activity\.registration_capacity/i);
    assert.match(migration, /activity_registrations_unique_email_idx/i);
    assert.match(migration, /activity_registrations_unique_student_idx/i);
    assert.match(paymentMigration, /activity_registration_private_settings/i);
    assert.match(paymentMigration, /get_activity_registration_confirmation/i);
    assert.match(paymentMigration, /grant all on table public\.activity_registration_payments to service_role/i);
    assert.match(paymentMigration, /revoke all on table public\.activity_registration_private_settings from public, anon, authenticated/i);
    assert.match(mustikaMigration, /set_activity_registration_checkout\(\s*p_order_id text,\s*p_checkout_url text,\s*p_transaction_id text/i);
    assert.match(mustikaMigration, /transaction_id = p_transaction_id/i);
    assert.match(mustikaMigration, /claim_activity_registration_payment_check/i);
    assert.match(mustikaMigration, /status_checked_at timestamptz/i);
    assert.match(groupInviteMigration, /drop constraint if exists activity_registration_private_settings_whatsapp_group_link_check/i);
    assert.match(groupInviteMigration, /discord\\\.com\/invite/i);
    assert.match(groupInviteMigration, /t\\\.me\|telegram\\\.me/i);
    assert.match(groupInviteConstraintMigration, /pg_get_constraintdef\(oid\) like '%whatsapp_group_link%'/i);
    assert.match(groupInviteConstraintMigration, /drop constraint %I/i);
    assert.match(groupInviteConstraintMigration, /add constraint activity_registration_group_link_check/i);
    assert.match(migration, /to service_role/i);
});

test("confirmation endpoint returns only the payment-specific group invite after registration", async () => {
    process.env.SUPABASE_URL = "https://project.supabase.co";
    process.env.SUPABASE_SERVICE_ROLE_KEY = "server-secret";
    let requestBody;
    let requestCount = 0;
    global.fetch = async (url, options) => {
        requestCount += 1;
        assert.equal(
            url,
            "https://project.supabase.co/rest/v1/rpc/get_activity_registration_confirmation"
        );
        requestBody = JSON.parse(options.body);
        return new Response(JSON.stringify({
            ok: true,
            status: "registered",
            whatsapp_group_link: "https://chat.whatsapp.com/InviteCode123",
        }), { status: 200 });
    };

    const response = makeResponse();
    await confirmationHandler({
        method: "GET",
        url: "/api/activity-registration-confirmation?order_id=HMPS-9b2f3b2a-ff51-4e31-b22f-9f18fdb68a11",
        headers: { host: "hmpssi.vercel.app" },
    }, response);

    assert.deepEqual(requestBody, { p_order_id: "HMPS-9b2f3b2a-ff51-4e31-b22f-9f18fdb68a11" });
    assert.deepEqual(response.body, {
        ok: true,
        status: "registered",
        whatsapp_group_link: "https://chat.whatsapp.com/InviteCode123",
    });
    assert.equal(response.headers["Cache-Control"], "no-store");
    assert.equal(requestCount, 1);

    global.fetch = async (url) => {
        assert.equal(
            url,
            "https://project.supabase.co/rest/v1/rpc/get_activity_registration_confirmation"
        );
        return new Response(JSON.stringify({
            ok: true,
            status: "pending",
            whatsapp_group_link: "https://chat.whatsapp.com/InviteCode123",
        }), { status: 200 });
    };
    const pendingResponse = makeResponse();
    await confirmationHandler({
        method: "GET",
        url: "/api/activity-registration-confirmation?order_id=HMPS-9b2f3b2a-ff51-4e31-b22f-9f18fdb68a11",
        headers: { host: "hmpssi.vercel.app" },
    }, pendingResponse);
    assert.deepEqual(pendingResponse.body, {
        ok: true,
        status: "pending",
        whatsapp_group_link: null,
    });
});

test("confirmation endpoint allows supported group invites and rejects unsafe links", async () => {
    process.env.SUPABASE_URL = "https://project.supabase.co";
    process.env.SUPABASE_SERVICE_ROLE_KEY = "server-secret";
    const inviteLinks = [
        ["https://chat.whatsapp.com/InviteCode123", "https://chat.whatsapp.com/InviteCode123"],
        ["https://t.me/HimsiGroup", "https://t.me/HimsiGroup"],
        ["https://t.me/+InviteCode123", "https://t.me/+InviteCode123"],
        ["https://discord.gg/Invite-Code", "https://discord.gg/Invite-Code"],
        ["https://discord.com/invite/Invite-Code", "https://discord.com/invite/Invite-Code"],
        ["https://discord.com.evil.example/invite/Invite-Code", null],
        ["http://discord.gg/Invite-Code", null],
        ["javascript:alert(1)", null],
    ];

    for (const [inviteLink, expectedLink] of inviteLinks) {
        global.fetch = async (url) => {
            assert.equal(
                url,
                "https://project.supabase.co/rest/v1/rpc/get_activity_registration_confirmation"
            );
            return new Response(JSON.stringify({
                ok: true,
                status: "registered",
                whatsapp_group_link: inviteLink,
            }), { status: 200 });
        };

        const response = makeResponse();
        await confirmationHandler({
            method: "GET",
            url: "/api/activity-registration-confirmation?order_id=HMPS-9b2f3b2a-ff51-4e31-b22f-9f18fdb68a11",
            headers: { host: "hmpssi.vercel.app" },
        }, response);

        assert.equal(response.statusCode, 200);
        assert.equal(response.body.whatsapp_group_link, expectedLink, inviteLink);
    }
});
